let pTags = document.getElementsByTagName('p');
let inputTags = document.getElementsByTagName('input');
//let xmlhttp = new XMLHttpRequest();
let file = "json.txt";
let url = "http://localhost:8000/getallrecords";
async function getData(){
	try{
		const response = await fetch(url);
		const jData =	await response.json();
		displayData(jData);
		console.log(jData);
	} catch(error){
		console.log(error);
	}
};
//
function displayData(arr) {
	let outHTML = "";
	for(let i=0; i < arr.length; i++){
		outHTML+="<p>"+arr[i].empName + " weighed " + arr[i].empWeight + " Kgs</p>";
	}
	document.getElementById("records").innerHTML = outHTML;
}
//
let badName = /^\D*$/;
function validateForm(){
	let empName = document.forms["frmCollectWeights"]["empName"];
	let empWeight = document.forms["frmCollectWeights"]["empWeight"];
	document.getElementById("nameMessage").innerHTML="";
	document.getElementById("weightMessage").innerHTML="";
	if (empName.value == "") {
		document.getElementById("nameMessage").innerHTML="Name cannot be empty!";
		empName.focus();
		return false;
	}
	if (!empName.value.match(badName)) {
		document.getElementById("nameMessage").innerHTML="Name cannot contain numbers!";
		empName.focus();
		return false;
	}
	if (empName.value.length < 2 && empName.value != "") {
		document.getElementById("nameMessage").innerHTML="Name too short!";
		empName.focus();
		return false;
	}
//
	if (empWeight.value == "") {
		document.getElementById("weightMessage").innerHTML="Weight cannot be empty!";
		empWeight.focus();
		return false;
	}
	if (isNaN(empWeight.value)) {
		document.getElementById("weightMessage").innerHTML="Weight must be a number";
		empWeight.focus();
		return false;
	}
//
	return true;
};
//
for(let i = 0; i < inputTags.length; i++) {
	inputTags[i].addEventListener('focus', function(){
			this.style.backgroundColor='lightyellow';
	}, false);
	inputTags[i].addEventListener('blur', function(){
			this.style.backgroundColor='';
	}, false);
};
//
for(let i = 0; i < pTags.length; i++) {
	pTags[i].addEventListener('mouseover', function(){
			this.style.backgroundColor='lightyellow';
	}, false);
	pTags[i].addEventListener('mouseout', function(){
			this.style.backgroundColor='';
	}, false);
};
